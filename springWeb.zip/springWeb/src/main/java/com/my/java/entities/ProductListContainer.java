package com.my.java.entities;

import java.util.List;

public class ProductListContainer {
   private List<Product> prods;

   public List<Product> getProds() {
	    return prods;
   }

   public void setProds(List<Product> prods) {
	    this.prods = prods;
   }
}