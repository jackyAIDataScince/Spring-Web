package com.my.java.controller;

import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.support.PagedListHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.HttpServletRequest;

import com.my.java.SpringWebApplication;
import com.my.java.entities.Product;
import com.my.java.entities.ProductListContainer;
import com.my.java.services.ProductService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller
@RequestMapping("product")
public class ProductController {
	private static final Logger logger = LoggerFactory.getLogger(ProductController.class);
	
	@Autowired
	private ProductService productService;
	
	@RequestMapping(method = RequestMethod.GET)
	public String index(HttpServletRequest request, ModelMap modelMap) {
		//modelMap.put("products", productService.findAll());
		List<Product> products = (List<Product>) productService.findAll();
		PagedListHolder pagedListHolder = new PagedListHolder(products);
		int page = ServletRequestUtils.getIntParameter(request, "p", 0);
		pagedListHolder.setPage(page);
		pagedListHolder.setPageSize(3);
		//logger.info("products " + products.size());
		String heading = "Spring MVC";
		String result1 = "RRR";
		String result2 = "result2.. ";
 
		String credit = "Demo by <a href='https://crunchify.com'>Crunchify</a>. Click <a href='https://crunchify.com/category/java-tutorials/'>here</a> for more than 350 Java Examples.";
 
		// you can add any Collection Objects to ModelMap
		// including JSON, String, Array, Map, List, etc...
		modelMap.addAttribute("heading", heading);
		modelMap.addAttribute("result1", result1);
		modelMap.addAttribute("result2", result2);
		modelMap.addAttribute("message", "Programmer Gate");
		
		return "product/index";
	}
	
	/*
	@RequestMapping(method = RequestMethod.GET)
	public String index(HttpServletRequest request, ModelMap modelMap) {
		List<Product> products = (List<Product>) productService.findAll();
		PagedListHolder pagedListHolder = new PagedListHolder(products);
		int page = ServletRequestUtils.getIntParameter(request, "p", 0);
		pagedListHolder.setPage(page);
		pagedListHolder.setPageSize(3);
		//modelMap.put("pagedListHolder", pagedListHolder);
		//System.out.println("debug" +pagedListHolder);
		modelMap.put("ma", "Hello, Hey!");
		logger.info(this.getClass() + "size " + pagedListHolder.getPageSize());
		
		logger.info("products " + products.size());
		String heading = "Spring MVC";
		String result1 = "RRR";
		String result2 = "result2.. ";
 
		String credit = "Demo by <a href='https://crunchify.com'>Crunchify</a>. Click <a href='https://crunchify.com/category/java-tutorials/'>here</a> for more than 350 Java Examples.";
 
		// you can add any Collection Objects to ModelMap
		// including JSON, String, Array, Map, List, etc...
		modelMap.addAttribute("heading", heading);
		modelMap.addAttribute("result1", result1);
		modelMap.addAttribute("result2", result2);
		modelMap.addAttribute("credit", credit);
		//modelMap.put("ma2",products.size());
		
		return "product/index";
	}
    */     
	
 
}