package com.my.java.services;

import com.my.java.entities.Product;
import com.my.java.repositories.ProductRepository;

public interface ProductService {

	public Iterable<Product> findAll();
	   
}